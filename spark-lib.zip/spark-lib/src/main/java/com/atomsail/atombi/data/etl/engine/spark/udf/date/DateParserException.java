package com.atomsail.atombi.data.etl.engine.spark.udf.date;

public class DateParserException extends Exception {
    public DateParserException() {
    }

    public DateParserException(String message) {
        super(message);
    }

    public DateParserException(String message, Throwable cause) {
        super(message, cause);
    }

    public DateParserException(Throwable cause) {
        super(cause);
    }

    public DateParserException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
