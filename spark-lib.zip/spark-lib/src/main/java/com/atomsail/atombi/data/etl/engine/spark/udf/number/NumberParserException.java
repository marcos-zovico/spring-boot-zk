package com.atomsail.atombi.data.etl.engine.spark.udf.number;

public class NumberParserException extends Exception {
    public NumberParserException() {
    }

    public NumberParserException(String message) {
        super(message);
    }

    public NumberParserException(String message, Throwable cause) {
        super(message, cause);
    }

    public NumberParserException(Throwable cause) {
        super(cause);
    }

    public NumberParserException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
