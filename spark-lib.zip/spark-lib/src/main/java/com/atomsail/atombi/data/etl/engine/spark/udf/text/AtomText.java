package com.atomsail.atombi.data.etl.engine.spark.udf.text;

import java.io.Serializable;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.sql.api.java.UDF2;

public class AtomText implements Serializable {
    
	private static final long serialVersionUID = 8488666207902053622L;
	
	public final static UDF2<String, String, String> atom_text = (value, fieldName) -> {

        try {
            if (StringUtils.isBlank(value)) {
                return " ";
            } else {
                return StringEscapeUtils.unescapeCsv(value);
            }
        } catch (Exception e) {
            throw new TextParserException("Não foi possível mapear a coluna texto '" + fieldName + "', com o valor '" + value + "'");
        }


    };
}
