package com.atomsail.atombi.data.etl.engine.spark.udf.date;

public class EmptyDateValueException extends Exception {

    public EmptyDateValueException() {
    }

    public EmptyDateValueException(String message) {
        super(message);
    }

    public EmptyDateValueException(String message, Throwable cause) {
        super(message, cause);
    }

    public EmptyDateValueException(Throwable cause) {
        super(cause);
    }

    public EmptyDateValueException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
