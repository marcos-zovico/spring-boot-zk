package com.atomsail.atombi.data.etl.engine.spark.udf.date;

import org.apache.commons.lang.StringUtils;
import org.apache.spark.sql.api.java.UDF3;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.DateTimeFormatterBuilder;
import org.joda.time.format.DateTimeParser;

import java.io.Serializable;

public class AtomTimeId implements Serializable {


	private static final long serialVersionUID = 1002969418528892679L;

	public final static UDF3<String, String, String, String> atom_time_id = (dateIn, format, fieldName) -> {

        if (StringUtils.isBlank(dateIn)) {
            throw new EmptyDateValueException("A coluna de data '"+fieldName+"' contém valores vazios.");
        }

        try {
            DateTimeParser[] parsers = {
                    DateTimeFormat.forPattern(format + " HH:mm:ss").getParser(),
                    DateTimeFormat.forPattern(format).getParser()};

            DateTimeFormatter formatter = new DateTimeFormatterBuilder().append(null, parsers).toFormatter();
            LocalDateTime dateTime = formatter.parseLocalDateTime(dateIn.trim());
            return dateTime.dayOfMonth().roundFloorCopy().toString("yyyyMMddHHmmss");
        } catch (Exception e) {

            throw new DateParserException("Não foi possível mapear a coluna data '"+fieldName+"', com o valor '"+dateIn+"' utilizando o formato '"+format+"'");
        }

    };
}
