package com.atomsail.atombi.data.etl.engine.spark.udf.number;

import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;
import org.apache.spark.sql.api.java.UDF3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AtomNumber implements Serializable {

	private static final long serialVersionUID = -4962680325499418313L;

	private static final Logger log = LoggerFactory.getLogger(AtomNumber.class);

    public final static UDF3<String, String, String, Double> atom_number = (value, decimalSymbol, fieldName) -> {

        if (StringUtils.isBlank(value)) {
            return null;
        }

        if (StringUtils.isBlank(decimalSymbol)) {
            decimalSymbol = ",";
            if (log.isDebugEnabled()) {
                log.debug("separador decimal não foi informado. Definindo padrão ','");
            }
        }

        if (value.split(decimalSymbol).length > 2) {
            throw new NumberParserException("Não foi possível mapear a coluna numérica '"+fieldName+"', com o valor '"+value+"' e separador decimal '"+decimalSymbol+"', pois o valor não formatado corretamente");
        }

        try {

            NumberFormat format;
            if (decimalSymbol.equals(",")) {
                format = NumberFormat.getInstance(new Locale("pt"));
            } else {
                format = NumberFormat.getInstance(Locale.ENGLISH);
            }

            Double number = format.parse(value.trim()).doubleValue();
            if (log.isTraceEnabled()) {
                log.trace("value {} -> parsed {}", value, number);
            }

            return number;
        } catch (Exception e) {
            throw new NumberParserException("Não foi possível mapear a coluna numérica '"+fieldName+"', com o valor '"+value+"' e separador decimal '"+decimalSymbol+"'");
        }


    };
}
