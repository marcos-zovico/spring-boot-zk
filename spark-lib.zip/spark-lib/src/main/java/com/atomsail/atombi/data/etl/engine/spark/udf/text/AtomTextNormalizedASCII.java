package com.atomsail.atombi.data.etl.engine.spark.udf.text;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.sql.api.java.UDF2;

import java.io.Serializable;
import java.text.Normalizer;

public class AtomTextNormalizedASCII implements Serializable {

	private static final long serialVersionUID = -4967612918685856796L;

	/**
     * Remove qualquer caracter com acentuaçao;
     * <pre>
     *     José         --> Jose
     *     áâãàçéêíóôõú --> aaaaceeiooou
     * <pre/>
     */
    public final static UDF2<String, String, String> atom_text_normalized_ascii = (value, fieldName) -> {

        try {

            if (StringUtils.isBlank(value)) {
                return " ";
            } else {
                String unescapedValue = StringEscapeUtils.unescapeCsv(value);
                return Normalizer.normalize(unescapedValue, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
            }

        } catch (Exception e) {
            throw new TextParserException("Não foi possível mapear a coluna texto '" + fieldName + "', com o valor '" + value + "'");
        }
    };
}
