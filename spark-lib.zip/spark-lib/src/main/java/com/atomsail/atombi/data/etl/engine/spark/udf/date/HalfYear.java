package com.atomsail.atombi.data.etl.engine.spark.udf.date;

import org.apache.spark.sql.api.java.UDF1;
import org.joda.time.DateTime;

import java.io.Serializable;
import java.util.Date;

public class HalfYear implements Serializable {

    public final static UDF1 halfyear = (UDF1<Date, Integer>) date -> {
        DateTime dateTime = new DateTime(date);
        Integer result = dateTime.getMonthOfYear() < 7 ? 1 : 2;
        return result;
    };
}
