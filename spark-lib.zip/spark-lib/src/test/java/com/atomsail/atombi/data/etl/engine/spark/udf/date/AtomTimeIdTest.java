package com.atomsail.atombi.data.etl.engine.spark.udf.date;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static com.atomsail.atombi.data.etl.engine.spark.udf.date.AtomTimeId.atom_time_id;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.fail;

public class AtomTimeIdTest {

    private transient SparkSession spark;

    @Before
    public void setUp() {
        spark = SparkSession.builder()
                .master("local[*]")
                .appName("testing")
                .getOrCreate();
    }

    @After
    public void tearDown() {
        spark.stop();
        spark = null;
    }

    @Test
    public void date1Test() {

        spark.udf().register("atom_time_id", atom_time_id, DataTypes.StringType);
        Row result = spark.sql("SELECT atom_time_id('21/10/2018', 'dd/MM/yyyy', 'Campo x')").head();
        assertEquals("20181021000000", result.getString(0));

    }

    @Test
    public void date2Test() {

        spark.udf().register("atom_time_id", atom_time_id, DataTypes.StringType);
        Row result = spark.sql("SELECT atom_time_id('21/10/2018 21:02:12', 'dd/MM/yyyy', 'Campo x')").head();
        assertEquals("20181021000000", result.getString(0));

    }

    @Test
    public void dateEmptyTest() {

        spark.udf().register("atom_time_id", atom_time_id, DataTypes.StringType);

        try {
            spark.sql("SELECT atom_time_id('', 'yyyy-MM-dd', 'Campo x')").head();
            fail();
        } catch (Exception e) {
            assertEquals(EmptyDateValueException.class, ExceptionUtils.getRootCause(e).getClass());
        }

    }
}