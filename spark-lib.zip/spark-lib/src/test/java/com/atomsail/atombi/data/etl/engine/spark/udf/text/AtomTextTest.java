package com.atomsail.atombi.data.etl.engine.spark.udf.text;

import static com.atomsail.atombi.data.etl.engine.spark.udf.text.AtomText.atom_text;
import static junit.framework.TestCase.assertEquals;

import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AtomTextTest  {

    private transient SparkSession spark;

    @Before
    public void setUp() {
        spark = SparkSession.builder()
                .master("local[*]")
                .appName("testing")
                .getOrCreate();
    }

    @After
    public void tearDown() {
        spark.stop();
        spark = null;
    }

    @Test
    public void udf1Test() {

        spark.udf().register("atom_text", atom_text, DataTypes.StringType);

        Row result = spark.sql("SELECT atom_text('      ', 'Campo x')").head();

        System.out.println(result.getString(0));
        assertEquals(" ", result.getString(0));
    }

    @Test
    public void udf2Test() {

        spark.udf().register("atom_text", atom_text, DataTypes.StringType);

        Row result = spark.sql("SELECT md5(atom_text('', 'Campo x'))").head();

        System.out.println(result.getString(0));
        assertEquals("7215ee9c7d9dc229d2921a40e899ec5f", result.getString(0));
    }


}