package com.atomsail.atombi.data.etl.engine.spark.udf.number;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.Serializable;

import static com.atomsail.atombi.data.etl.engine.spark.udf.number.AtomNumber.atom_number;
import static junit.framework.TestCase.*;

public class AtomNumberTest implements Serializable {

    private transient SparkSession spark;

    @Before
    public void setUp() {
        spark = SparkSession.builder()
                .master("local[*]")
                .appName("testing")
                .getOrCreate();
    }

    @After
    public void tearDown() {
        spark.stop();
        spark = null;
    }

    @Test
    public void udf0Test() {

        spark.udf().register("atom_number", atom_number, DataTypes.DoubleType);

        Row result = spark.sql("SELECT atom_number('10000', '', 'Campo x')").head();

        System.out.println(result);
        assertEquals(10000d, result.getDouble(0));
    }

    @Test
    public void udf1Test() {

        spark.udf().register("atom_number", atom_number, DataTypes.DoubleType);

        Row result = spark.sql("SELECT atom_number('10000,00001', ',', 'Campo x')").head();

        System.out.println();
        assertEquals(10000.00001d, result.getDouble(0));
    }

    @Test
    public void udf2Test() {

        spark.udf().register("atom_number", atom_number, DataTypes.DoubleType);

        Row result = spark.sql("SELECT atom_number('10000,00001', '.', 'Campo x')").head();

        System.out.println();
        assertEquals(1000000001d, result.getDouble(0));
    }

    @Test
    public void udf3Test() {

        spark.udf().register("atom_number", atom_number, DataTypes.DoubleType);

        Row result = spark.sql("SELECT atom_number('1,000,001.01', '.', 'Campo x')").head();

        System.out.println();
        assertEquals(1000001.01d, result.getDouble(0));
    }

    @Test
    public void udf4Test() {

        spark.udf().register("atom_number", atom_number, DataTypes.DoubleType);

        Row result = spark.sql("SELECT atom_number('1.000.001,01', ',', 'Campo x')").head();

        System.out.println();
        assertEquals(1000001.01d, result.getDouble(0));
    }

    @Test
    public void udf5Test() {

        spark.udf().register("atom_number", atom_number, DataTypes.DoubleType);

        Row result = spark.sql("SELECT atom_number('  1.000.001,01', ',', 'Campo x')").head();

        System.out.println();
        assertEquals(1000001.01d, result.getDouble(0));
    }

    @Test
    public void udf6Test() {

        spark.udf().register("atom_number", atom_number, DataTypes.DoubleType);

        Row result = spark.sql("SELECT atom_number('1.000.001,01   ', ',', 'Campo x')").head();

        System.out.println();
        assertEquals(1000001.01d, result.getDouble(0));
    }

    @Test
    public void udf7Test() {

        spark.udf().register("atom_number", atom_number, DataTypes.DoubleType);

        Row result = spark.sql("SELECT atom_number('   1.000.001,01   ', ',', 'Campo x')").head();

        assertEquals(1000001.01d, result.getDouble(0));
    }


    @Test
    public void emptyTextTest() {

        spark.udf().register("atom_number", atom_number, DataTypes.DoubleType);

        Row result = spark.sql("SELECT atom_number('', ',', 'Campo x')").head();

        assertNull(result.get(0));
    }

    @Test
    public void textTest() {

        spark.udf().register("atom_number", atom_number, DataTypes.DoubleType);

        try {
            spark.sql("SELECT atom_number('abobora', ',', 'Campo x')").head();
            fail();
        } catch (Exception e) {
            assertEquals("Não foi possível mapear a coluna numérica 'Campo x', com o valor 'abobora' e separador decimal ','", ExceptionUtils.getRootCause(e).getMessage());
        }

    }

    @Test
    public void badFormatTest() {

        try {
            spark.udf().register("atom_number", atom_number, DataTypes.DoubleType);

            spark.sql("SELECT atom_number('   1,000,001,01   ', ',', 'Campo x')").head();
            fail();

        } catch (Exception e) {
            assertEquals("Não foi possível mapear a coluna numérica 'Campo x', com o valor '   1,000,001,01   ' e separador decimal ',', pois o valor não formatado corretamente", ExceptionUtils.getRootCause(e).getMessage());
        }
    }

    @Test
    public void badFormat2Test() {

        spark.udf().register("atom_number", atom_number, DataTypes.DoubleType);

        Row result = spark.sql("SELECT atom_number('   1.000.00,01   ', ',', 'Campo x')").head();
        assertEquals(100000.01d, result.getDouble(0));

    }
}