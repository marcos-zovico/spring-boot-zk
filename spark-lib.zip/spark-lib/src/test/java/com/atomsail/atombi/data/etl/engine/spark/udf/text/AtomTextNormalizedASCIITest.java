package com.atomsail.atombi.data.etl.engine.spark.udf.text;

import static com.atomsail.atombi.data.etl.engine.spark.udf.text.AtomTextNormalizedASCII.atom_text_normalized_ascii;
import static junit.framework.TestCase.assertEquals;

import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AtomTextNormalizedASCIITest {

    private SparkSession spark;

    @Before
    public void setUp() {
        spark = SparkSession.builder()
                .master("local[*]")
                .appName("testing")
                .getOrCreate();
        
        spark.udf().register("atom_text_normalized_ascii", atom_text_normalized_ascii, DataTypes.StringType);
    }

    @After
    public void tearDown() {
        spark.stop();
        spark = null;
    }

    @Test
    public void udf1Test() {
        
        Row result = spark.sql("SELECT atom_text_normalized_ascii('áâãàçéêíóôõú', 'Campo x')").head();

        System.out.println(result.getString(0));
        assertEquals("aaaaceeiooou", result.getString(0));
    }

    @Test
    public void udf2Test() {

        Row result = spark.sql("SELECT md5(atom_text_normalized_ascii('áâãàçéêíóôõú', 'Campo x'))").head();

        System.out.println(result.getString(0));
        assertEquals("745441972a16e2d76223aaffc45dfb0e", result.getString(0));
    }


}