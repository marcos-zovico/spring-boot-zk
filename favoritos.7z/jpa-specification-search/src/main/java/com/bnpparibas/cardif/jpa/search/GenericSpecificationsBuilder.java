package com.bnpparibas.cardif.jpa.search;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;

import java.util.*;
import java.util.function.Function;

import static com.bnpparibas.cardif.jpa.search.SearchOperation.AND_OPERATOR;
import static com.bnpparibas.cardif.jpa.search.SearchOperation.OR_OPERATOR;

public class GenericSpecificationsBuilder<U> {

    private final List<SearchCriteria> params;

    public GenericSpecificationsBuilder() {
        this.params = new ArrayList<>();
    }


    public final GenericSpecificationsBuilder<U> with(final String key, final String operation, final String value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }


    public Specification<U> build(Deque<?> postFixedExprStack, Function<SearchCriteria, Specification<U>> converter) {

        Deque<Specification<U>> specStack = new LinkedList<>();

        Collections.reverse((List<?>) postFixedExprStack);

        while (!postFixedExprStack.isEmpty()) {
            Object mayBeOperand = postFixedExprStack.pop();

            if (!(mayBeOperand.getClass().isAssignableFrom(String.class))) {
                specStack.push(converter.apply((SearchCriteria) mayBeOperand));
            } else {
                Specification<U> operand1 = specStack.pop();
                Specification<U> operand2 = specStack.pop();
                if (mayBeOperand.equals(AND_OPERATOR))
                    specStack.push(Specifications.where(operand1).and(operand2));
                else if (mayBeOperand.equals(OR_OPERATOR))
                    specStack.push(Specifications.where(operand1).or(operand2));
            }

        }
        return specStack.pop();
    }

}
