package com.bnpparibas.cardif.jpa.search;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;

import java.util.Arrays;
import java.util.List;

import static java.text.MessageFormat.format;

public enum SearchOperation implements ISearchOperation {
    EQUALITY {
        @Override
        public Predicate toPredicate(CriteriaBuilder builder, Path path, SearchCriteria criteria) {
            return builder.equal(path, (Comparable) getCorrectValue(path, criteria.getValue()));
        }
    },
    NEGATION {
        @Override
        public Predicate toPredicate(CriteriaBuilder builder, Path path, SearchCriteria criteria) {
            return builder.notEqual(path, (Comparable) getCorrectValue(path, criteria.getValue()));
        }
    },
    GREATER_THAN {
        @Override
        public Predicate toPredicate(CriteriaBuilder builder, Path path, SearchCriteria criteria) {
            return builder.greaterThanOrEqualTo(path, (Comparable) getCorrectValue(path, criteria.getValue()));
        }
    },
    LESS_THAN {
        @Override
        public Predicate toPredicate(CriteriaBuilder builder, Path path, SearchCriteria criteria) {
            return builder.lessThanOrEqualTo(path, (Comparable) getCorrectValue(path, criteria.getValue()));
        }
    },
    LIKE {
        @Override
        public Predicate toPredicate(CriteriaBuilder builder, Path path, SearchCriteria criteria) {
            return builder.like(builder.upper(path), format("%{0}%", String.valueOf(criteria.getValue()).toUpperCase()));
        }
    };

    protected static final List<String> SIMPLE_OPERATION_SET = Arrays.asList(":", "!", ">", "<", "~");
    public static final String OR_OPERATOR = "OR";
    public static final String AND_OPERATOR = "AND";
    public static final String LEFT_PARENTHESIS = "(";
    public static final String RIGHT_PARENTHESIS = ")";

    public static SearchOperation getSimpleOperation(final char input) {
        switch (input) {
            case ':':
                return EQUALITY;
            case '!':
                return NEGATION;
            case '>':
                return GREATER_THAN;
            case '<':
                return LESS_THAN;
            case '~':
                return LIKE;
            default:
                return null;
        }
    }

}
