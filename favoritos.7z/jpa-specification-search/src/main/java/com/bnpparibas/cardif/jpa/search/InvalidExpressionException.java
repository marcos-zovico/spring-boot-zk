package com.bnpparibas.cardif.jpa.search;

public class InvalidExpressionException extends RuntimeException {

    public InvalidExpressionException(String message) {
        super(message);
    }
}
