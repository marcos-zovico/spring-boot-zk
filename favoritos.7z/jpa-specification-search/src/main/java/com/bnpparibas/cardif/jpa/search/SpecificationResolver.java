package com.bnpparibas.cardif.jpa.search;

import org.springframework.data.jpa.domain.Specification;

import java.util.function.Function;

public class SpecificationResolver<U> {

    private Function<SearchCriteria, Specification<U>> specificationFunction;

    public SpecificationResolver(Function<SearchCriteria, Specification<U>> specificationFunction){
        this.specificationFunction = specificationFunction;
    }

    public Specification<U> parse(String searchParameters) {
        CriteriaParser parser = new CriteriaParser();
        GenericSpecificationsBuilder<U> specBuilder = new GenericSpecificationsBuilder<>();
        return specBuilder.build(parser.parse(searchParameters), specificationFunction);
    }

}
