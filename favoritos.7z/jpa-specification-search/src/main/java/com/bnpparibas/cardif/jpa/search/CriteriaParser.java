package com.bnpparibas.cardif.jpa.search;

import java.text.MessageFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.bnpparibas.cardif.jpa.search.SearchOperation.*;

public class CriteriaParser {

    private static Map<String, Operator> operands;
    private static final Pattern PARENTHESIS_REGEX = Pattern.compile("[()]");


    private enum Operator {
        OR(1), AND(2);
        final int precedence;

        Operator(int p) {
            precedence = p;
        }
    }

    static {
        Map<String, Operator> tempMap = new HashMap<>();
        tempMap.put("AND", Operator.AND);
        tempMap.put("OR", Operator.OR);
        tempMap.put("or", Operator.OR);
        tempMap.put("and", Operator.AND);
        tempMap.put("&", Operator.AND);
        tempMap.put("|", Operator.OR);

        operands = Collections.unmodifiableMap(tempMap);
    }

    private static boolean isHigerPrecedenceOperator(String currOp, String prevOp) {
        return (operands.containsKey(prevOp) && operands.get(prevOp).precedence >= operands.get(currOp).precedence);
    }

    public Deque parse(String searchParam) {

        if (!isBalanced(searchParam)) {
            throw new InvalidExpressionException(MessageFormat.format("The expression ''{0}'' is invalid, the parenthesis must be balanced.", searchParam));
        }

        Deque<Object> output = new LinkedList<>();
        Deque<String> stack = new LinkedList<>();
        CriteriaParserHelper helper = new CriteriaParserHelper(searchParam);

        String mappedSearch = helper.getMappedStringSearch();

        Arrays.stream(mappedSearch.split("\\s+")).forEach(token -> parseToken(output, stack, token, helper));

        while (!stack.isEmpty()) {
            output.push(stack.pop());
        }

        return output;
    }

    private void parseToken(Deque<Object> output, Deque<String> stack, String token, CriteriaParserHelper helper) {

        if (operands.containsKey(token)) {
            parseOperators(output, stack, token);
        } else if (token.equals(LEFT_PARENTHESIS)) {
            stack.push(LEFT_PARENTHESIS);
        } else if (token.equals(RIGHT_PARENTHESIS)) {
            while (!stack.peek().equals(LEFT_PARENTHESIS)) {
                output.push(stack.pop());
            }
            stack.pop();
        } else {
            output.push(helper.getMappedSearch().get(token));
        }
    }

    private void parseOperators(Deque<Object> output, Deque<String> stack, String token) {
        while (!stack.isEmpty() && isHigerPrecedenceOperator(token, stack.peek())) {
            output.push(stack.pop().equalsIgnoreCase(OR_OPERATOR) ? OR_OPERATOR : AND_OPERATOR);
        }
        stack.push(token.equalsIgnoreCase(OR_OPERATOR) ? OR_OPERATOR : AND_OPERATOR);
    }

    private boolean isBalanced(String searchParam) {

        Deque<Character> stack = new ArrayDeque<>();
        StringBuilder parenthesis = new StringBuilder();

        Matcher matcher = PARENTHESIS_REGEX.matcher(searchParam);

        while (matcher.find()) {
            parenthesis.append(matcher.group(0));
        }

        for (char c : parenthesis.toString().toCharArray()) {

            if (c == '(') {
                stack.push(')');
            } else if (stack.isEmpty() || c != stack.peek()) {
                return false;
            } else {
                stack.pop();
            }
        }
        return stack.isEmpty();
    }

}
