package com.bnpparibas.cardif.jpa.search;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import java.time.LocalDate;

@FunctionalInterface
public interface ISearchOperation {

    Predicate toPredicate(CriteriaBuilder builder, Path path, SearchCriteria criteria);

    default <T> T getCorrectValue(Path path, String value) {

        if (path.getJavaType().isAssignableFrom(Long.class)) {
            return (T) Long.valueOf(value);
        }

        if (path.getJavaType().isAssignableFrom(Boolean.class)) {
            return (T) Boolean.valueOf(value);
        }

        if (path.getJavaType().isAssignableFrom(LocalDate.class)) {
            return (T) LocalDate.parse(value);
        }

        if (path.getJavaType().isEnum()) {
            return (T) Enum.valueOf(path.getJavaType(), value);
        }

        return (T) value;
    }

}
