package com.bnpparibas.cardif.jpa.search;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.bnpparibas.cardif.jpa.search.SearchOperation.SIMPLE_OPERATION_SET;
import static java.text.MessageFormat.format;

public class CriteriaParserHelper {

    private static final String VALUE_PATTERN = "{0}{1}{2}";
    private static final String KEY_PATTERN = "KEY_{0}";
    private static final String OPERATION_SET = String.join("|", SIMPLE_OPERATION_SET);
    public static final Pattern SPEC_CRITERIA_REGEX = Pattern.compile("(\\w+?|\\w+?.\\w+?)(" + OPERATION_SET + ")([\\w+ ?!@#$&\\/-]+\\s+?[\\w+ ?!@#$&\\/-]+\\w|[0-9]+[\\w+-]+\\w|\\w+)");

    private String mappedStringSearch;
    private Map<String, SearchCriteria> mappedSearch;
    private List<SearchCriteria> criteriaList;

    public CriteriaParserHelper(final String search) {
        parse(search);
    }

    private void parse(String search) {
        mappedSearch = new HashMap<>();
        criteriaList = new ArrayList<>();
        mappedStringSearch = search;
        int i = 0;

        String searchMatcher = search.replaceAll(" (?i)or ", ",").replaceAll(" (?i)and ", ",");

        Matcher matcher = SPEC_CRITERIA_REGEX.matcher(searchMatcher);

        while (matcher.find()) {
            String key = matcher.group(1);
            String op = matcher.group(2);
            String value = matcher.group(3);

            SearchCriteria searchCriteria = new SearchCriteria(key, op, value);

            String criteriaValue = format(VALUE_PATTERN, key, op, value);
            String criteriaKey = format(KEY_PATTERN, ++i);

            mappedStringSearch = mappedStringSearch.replace(criteriaValue, criteriaKey);
            criteriaList.add(searchCriteria);
            mappedSearch.put(criteriaKey, searchCriteria);
        }

        mappedStringSearch = mappedStringSearch.replaceAll("\\(", "( ").replaceAll("\\)", " )");
    }


    public String getMappedStringSearch() {
        return mappedStringSearch;
    }

    public Map<String, SearchCriteria> getMappedSearch() {
        return mappedSearch;
    }

    public List<SearchCriteria> getCriteriaList() {
        return criteriaList;
    }
}
