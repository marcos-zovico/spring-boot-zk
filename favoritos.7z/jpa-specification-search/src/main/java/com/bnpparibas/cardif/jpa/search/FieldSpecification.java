package com.bnpparibas.cardif.jpa.search;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

@FunctionalInterface
public interface FieldSpecification {

    Predicate toPredicate(CriteriaBuilder builder, Root<?> root, SearchCriteria criteria);

}
