package com.bnpparibas.cardif.jpa.search;


public class SearchCriteria {

    private String key;
    private SearchOperation operation;
    private String value;

    public SearchCriteria() {
    }

    public SearchCriteria(final String key, final SearchOperation operation, final String value) {
        this.key = key;
        this.operation = operation;
        this.value = value;
    }

    public SearchCriteria(final String key, final String operation, final String value) {
        this(key, SearchOperation.getSimpleOperation(operation.charAt(0)), value);
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public SearchOperation getOperation() {
        return operation;
    }

    public void setOperation(SearchOperation operation) {
        this.operation = operation;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


}
