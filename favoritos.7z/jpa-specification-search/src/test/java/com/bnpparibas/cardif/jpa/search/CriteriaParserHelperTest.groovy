package com.bnpparibas.cardif.jpa.search


import spock.lang.Specification

class CriteriaParserHelperTest extends Specification {


  def "Should parser a criteria param with value separated by space "() {

    given:
    String searchParam = "(firstName:John Lennon OR lastName:Jose)"

    when:
    CriteriaParserHelper helper = new CriteriaParserHelper(searchParam)

    then:
    assert helper.getMappedStringSearch() == "( KEY_1 OR KEY_2 )"

    and:
    assert !helper.getCriteriaList().isEmpty()
    assert helper.getCriteriaList().size() == 2

    and:
    assert helper.getCriteriaList().get(0).getKey() == "firstName"
    assert helper.getCriteriaList().get(0).getOperation() == SearchOperation.EQUALITY
    assert helper.getCriteriaList().get(0).getValue() == "John Lennon"

    and:
    assert helper.getCriteriaList().get(1).getKey() == "lastName"
    assert helper.getCriteriaList().get(1).getOperation() == SearchOperation.EQUALITY
    assert helper.getCriteriaList().get(1).getValue() == "Jose"


    when:
    searchParam = "(firstName:John Lennon OR lastName:Jose) AND birthDate<28-09-2018"
    helper = new CriteriaParserHelper(searchParam)

    then:
    assert helper.getMappedStringSearch() == "( KEY_1 OR KEY_2 ) AND KEY_3"

    and:
    assert !helper.getCriteriaList().isEmpty()
    assert helper.getCriteriaList().size() == 3

    and:
    assert helper.getCriteriaList().get(0).getKey() == "firstName"
    assert helper.getCriteriaList().get(0).getOperation() == SearchOperation.EQUALITY
    assert helper.getCriteriaList().get(0).getValue() == "John Lennon"

    and:
    assert helper.getMappedSearch().get("KEY_1").getKey() == "firstName"
    assert helper.getMappedSearch().get("KEY_1").getOperation() == SearchOperation.EQUALITY
    assert helper.getMappedSearch().get("KEY_1").getValue() == "John Lennon"

    and:
    assert helper.getCriteriaList().get(1).getKey() == "lastName"
    assert helper.getCriteriaList().get(1).getOperation() == SearchOperation.EQUALITY
    assert helper.getCriteriaList().get(1).getValue() == "Jose"

    and:
    assert helper.getCriteriaList().get(2).getKey() == "birthDate"
    assert helper.getCriteriaList().get(2).getOperation() == SearchOperation.LESS_THAN
    assert helper.getCriteriaList().get(2).getValue() == "28-09-2018"

  }

}

